const fingerauth = require(".");
fingerauth();
